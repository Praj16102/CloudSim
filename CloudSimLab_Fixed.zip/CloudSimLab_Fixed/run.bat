@echo off
cd /d "%~dp0"
if not exist "bin\App.class" (
  echo App.class not found. Run compile.bat first.
  pause
  exit /b 1
)
java -cp "bin;lib\cloudsim-3.0.3.jar" App
pause
