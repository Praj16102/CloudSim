//import org.cloudbus.cloudsim.*;
//import org.cloudbus.cloudsim.core.CloudSim;
//import java.text.DecimalFormat;
//import java.util.*;

import org.cloudbus.cloudsim.*;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;

import java.text.DecimalFormat;
import java.util.*;

public class App {
    public static void main(String[] args) {
        System.out.println("Starting Terminal-Based CloudSim Lab Simulation...");
        try {
            // Step 1: Initialize CloudSim core engine
            int numUser = 1;
            Calendar calendar = Calendar.getInstance();
            CloudSim.init(numUser, calendar, false);

            // Step 2: Create Infrastructure Components
            Datacenter datacenter0 = createDatacenter("Datacenter_0");
            DatacenterBroker broker = new DatacenterBroker("Broker");
            int brokerId = broker.getId();

            // Step 3: Configure 2 Virtual Machines (VMs)
            List<Vm> vmlist = new ArrayList<Vm>();
            int vmid = 0;
            int mips = 1000;
            long size = 10000; 
            int ram = 512; 
            long bw = 1000;
            int pesNumber = 1; // Single-core VMs

            /* 
             * EXERCISE CRITICAL STEP: 
             * RUN 1: Set both to new CloudletSchedulerSpaceShared()
             * RUN 2: Set both to new CloudletSchedulerTimeShared()
             */
            Vm vm1 = new Vm(vmid++, brokerId, mips, pesNumber, ram, bw, size, "Xen", new CloudletSchedulerSpaceShared());
            Vm vm2 = new Vm(vmid++, brokerId, mips, pesNumber, ram, bw, size, "Xen", new CloudletSchedulerSpaceShared());
            
            vmlist.add(vm1);
            vmlist.add(vm2);
            broker.submitVmList(vmlist);

            // Step 4: Configure 4 Cloudlets (Tasks)
            List<Cloudlet> cloudletList = new ArrayList<Cloudlet>();
            int id = 0;
            long length = 40000; // 40,000 Millions of Instructions (MI)
            long fileSize = 300;
            long outputSize = 300;
            UtilizationModel utilizationModel = new UtilizationModelFull();

            for(int i = 0; i < 4; i++) {
                Cloudlet cloudlet = new Cloudlet(id++, length, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
                cloudlet.setUserId(brokerId);
                cloudlet.setVmId(i % 2); // Dispatches Cloudlets dynamically alternating between VM 0 and VM 1
                cloudletList.add(cloudlet);
            }
            broker.submitCloudletList(cloudletList);

            // Step 5: Execute Simulation Run
            CloudSim.startSimulation();
            CloudSim.stopSimulation();

            // Step 6: Fetch Output
            List<Cloudlet> newList = broker.getCloudletReceivedList();
            printCloudletList(newList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Datacenter createDatacenter(String name) throws Exception {
        List<Host> hostList = new ArrayList<Host>();
        List<Pe> peList = new ArrayList<Pe>();
        peList.add(new Pe(0, new PeProvisionerSimple(2000))); // 2000 MIPS CPU Core

        hostList.add(new Host(0, new RamProvisionerSimple(2048), new BwProvisionerSimple(10000),
                1000000, peList, new VmSchedulerTimeShared(peList)));

        DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
                "x86", "Linux", "Xen", hostList, 10.0, 3.0, 0.05, 0.001, 0.0);
        
        return new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), new LinkedList<Storage>(), 0);
    }

    private static void printCloudletList(List<Cloudlet> list) {
        String indent = "    ";
        System.out.println("\n========== SIMULATION OUTPUT WINDOW ==========");
        System.out.println("Cloudlet ID" + indent + "STATUS" + indent + "VM ID" + indent + "Time Taken" + indent + "Start Time" + indent + "Finish Time");
        DecimalFormat dft = new DecimalFormat("###.##");
        for (Cloudlet cloudlet : list) {
            System.out.print(indent + cloudlet.getCloudletId() + indent + indent);
            if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
                System.out.println("SUCCESS" + indent + indent + cloudlet.getVmId() + indent + indent + dft.format(cloudlet.getActualCPUTime()) + indent + indent + dft.format(cloudlet.getExecStartTime()) + indent + indent + dft.format(cloudlet.getFinishTime()));
            }
        }
    }
}