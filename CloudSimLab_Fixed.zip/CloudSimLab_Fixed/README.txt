CLOUDSIM 3.0.3 - APP.JAVA LAB PROJECT

Folder contents:
- App.java: your uploaded Java program (kept unchanged)
- lib\cloudsim-3.0.3.jar: compiled CloudSim library required to compile/run
- lib\cloudsim-3.0.3-sources.jar: CloudSim source archive
- lib\cloudsim-examples-3.0.3.jar: CloudSim examples archive
- lib\cloudsim-examples-3.0.3-sources.jar: examples source archive
- bin\: generated .class files
- compile.bat: compile the program on Windows
- run.bat: run the simulation on Windows

HOW TO USE
1. Extract this complete folder anywhere on your Windows computer.
2. Ensure JDK 21 is installed and java/javac are available in CMD PATH.
3. Double-click compile.bat (or run it from CMD).
4. After successful compilation, double-click run.bat.

Manual commands from this folder:
  javac -cp ".;lib\cloudsim-3.0.3.jar" -d bin App.java
  java -cp "bin;lib\cloudsim-3.0.3.jar" App

The uploaded App.java compiled and ran successfully in a JDK 21 test environment
using CloudSim 3.0.3 and the main JAR alone. No commons-math JAR was needed
for this program in that test.
