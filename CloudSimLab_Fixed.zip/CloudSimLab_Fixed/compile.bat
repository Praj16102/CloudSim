@echo off
cd /d "%~dp0"
if not exist "lib\cloudsim-3.0.3.jar" (
  echo ERROR: lib\cloudsim-3.0.3.jar is missing.
  pause
  exit /b 1
)
if not exist bin mkdir bin
javac -cp ".;lib\cloudsim-3.0.3.jar" -d bin App.java
if errorlevel 1 (
  echo Compilation failed. Check the error messages above.
  pause
  exit /b 1
)
echo Compilation successful.
pause
